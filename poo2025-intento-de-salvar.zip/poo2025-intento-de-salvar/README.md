Clases y Métodos 
<img width="1260" height="1977" alt="image" src="https://github.com/user-attachments/assets/881fc2ec-01ec-4ee1-a2b0-73b636873b40" />

Interacción en Interfaz

<img width="936" height="1321" alt="image" src="https://github.com/user-attachments/assets/b68f5b07-3c21-478f-93f9-88ca1f2702dd" />

